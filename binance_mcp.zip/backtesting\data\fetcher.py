from __future__ import annotations
import logging
from decimal import Decimal
from datetime import datetime, timedelta
from typing import Optional, List, Dict
import asyncio
from dataclasses import dataclass

import aiohttp

from exchange import UnifiedExchangeManager, MarketType, OHLCV

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Live Binance public endpoints for historical OHLCV data.
#
# WHY always live and never testnet:
#   - Binance testnet (testnet.binancefuture.com) holds NO historical candle
#     data — it is a sandbox for order execution only.
#   - The klines endpoint is fully public — no API key is required.
#   - Backtesting must always use real market history regardless of whether
#     the system is in paper/testnet trading mode.
# ---------------------------------------------------------------------------
_LIVE_KLINES_URL: dict[MarketType, str] = {
    MarketType.SPOT: "https://api.binance.com/api/v3/klines",
    MarketType.USDM_FUTURES: "https://fapi.binance.com/fapi/v1/klines",
    MarketType.COINM_FUTURES: "https://dapi.binance.com/dapi/v1/klines",
    MarketType.MARGIN: "https://api.binance.com/api/v3/klines",
}

TIMEFRAME_MINUTES = {
    "1m": 1,
    "3m": 3,
    "5m": 5,
    "15m": 15,
    "30m": 30,
    "1h": 60,
    "2h": 120,
    "4h": 240,
    "6h": 360,
    "8h": 480,
    "12h": 720,
    "1d": 1440,
    "3d": 4320,
    "1w": 10080,
    "1M": 43200,
}

BINANCE_KLINE_LIMITS = {
    MarketType.SPOT: 1000,
    MarketType.USDM_FUTURES: 1500,
    MarketType.COINM_FUTURES: 1500,
    MarketType.MARGIN: 1000,
}


@dataclass
class HistoricalDataFetchResult:
    symbol: str
    timeframe: str
    market_type: MarketType
    total_candles: int
    start_time: datetime
    end_time: datetime
    data: List[OHLCV]
    gaps_detected: List[tuple[datetime, datetime]]
    fetch_errors: List[str]


class HistoricalDataFetcher:
    def __init__(
        self,
        exchange_manager: UnifiedExchangeManager,
        batch_delay: float = 0.1,
    ):
        self.exchange = exchange_manager
        self.batch_delay = batch_delay
        self._data_cache: Dict[str, List[OHLCV]] = {}
        self._cache_timestamps: Dict[str, datetime] = {}

    def _get_cache_key(
        self,
        symbol: str,
        market_type: MarketType,
        timeframe: str,
    ) -> str:
        return f"{symbol}_{market_type.value}_{timeframe}"

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def fetch_klines(
        self,
        symbol: str,
        market_type: MarketType,
        timeframe: str,
        start_time: datetime,
        end_time: datetime,
        use_cache: bool = True,
    ) -> HistoricalDataFetchResult:
        cache_key = self._get_cache_key(symbol, market_type, timeframe)

        if use_cache and cache_key in self._data_cache:
            cached_data = self._data_cache[cache_key]
            logger.debug(
                "Using cached data for %s | %d candles",
                cache_key,
                len(cached_data),
            )
            return HistoricalDataFetchResult(
                symbol=symbol,
                timeframe=timeframe,
                market_type=market_type,
                total_candles=len(cached_data),
                start_time=cached_data[0].timestamp if cached_data else start_time,
                end_time=cached_data[-1].timestamp if cached_data else end_time,
                data=cached_data,
                gaps_detected=[],
                fetch_errors=[],
            )

        if timeframe not in TIMEFRAME_MINUTES:
            return HistoricalDataFetchResult(
                symbol=symbol,
                timeframe=timeframe,
                market_type=market_type,
                total_candles=0,
                start_time=start_time,
                end_time=end_time,
                data=[],
                gaps_detected=[],
                fetch_errors=[f"Unknown timeframe: {timeframe}"],
            )

        all_candles, errors = await self._fetch_from_live_api(
            symbol=symbol,
            market_type=market_type,
            timeframe=timeframe,
            start_time=start_time,
            end_time=end_time,
        )

        all_candles = sorted(all_candles, key=lambda k: k.timestamp)
        timeframe_minutes = TIMEFRAME_MINUTES[timeframe]
        detected_gaps = self._detect_gaps(all_candles, timeframe_minutes)

        if use_cache:
            self._data_cache[cache_key] = all_candles
            self._cache_timestamps[cache_key] = datetime.utcnow()

        logger.info(
            "Fetched %d candles for %s | %s | Gaps: %d | Errors: %d",
            len(all_candles),
            symbol,
            timeframe,
            len(detected_gaps),
            len(errors),
        )

        return HistoricalDataFetchResult(
            symbol=symbol,
            timeframe=timeframe,
            market_type=market_type,
            total_candles=len(all_candles),
            start_time=all_candles[0].timestamp if all_candles else start_time,
            end_time=all_candles[-1].timestamp if all_candles else end_time,
            data=all_candles,
            gaps_detected=detected_gaps,
            fetch_errors=errors,
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    async def _fetch_from_live_api(
        self,
        symbol: str,
        market_type: MarketType,
        timeframe: str,
        start_time: datetime,
        end_time: datetime,
    ) -> tuple[List[OHLCV], List[str]]:
        """Fetch klines directly from the LIVE Binance public REST API.

        This bypasses the exchange manager's HTTP client (which may be
        configured for testnet).  The klines endpoint is public — no API key
        or signature is required.
        """
        url = _LIVE_KLINES_URL.get(market_type, _LIVE_KLINES_URL[MarketType.USDM_FUTURES])
        limit = BINANCE_KLINE_LIMITS.get(market_type, 1000)
        timeframe_minutes = TIMEFRAME_MINUTES[timeframe]
        candle_duration = timedelta(minutes=timeframe_minutes)

        all_candles: List[OHLCV] = []
        errors: List[str] = []

        current_start = start_time
        total_batches = 0

        timeout = aiohttp.ClientTimeout(total=30)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            while current_start < end_time:
                batch_start_ms = int(current_start.timestamp() * 1000)
                batch_end_ms = int(
                    (current_start + timedelta(minutes=timeframe_minutes * limit)).timestamp()
                    * 1000
                )
                params = {
                    "symbol": symbol,
                    "interval": timeframe,
                    "limit": limit,
                    "startTime": batch_start_ms,
                    "endTime": batch_end_ms,
                }
                try:
                    async with session.get(url, params=params) as resp:
                        if resp.status == 429:
                            retry_after = int(resp.headers.get("Retry-After", 60))
                            logger.warning("Rate limit hit, waiting %d s", retry_after)
                            await asyncio.sleep(retry_after)
                            continue

                    if resp.status >= 400:
                        text = await resp.text()
                        err = f"Batch {total_batches} HTTP {resp.status}: {text[:120]}"
                        errors.append(err)
                        logger.error(err)
                        if resp.status == 429:
                            await asyncio.sleep(5)
                        current_start += candle_duration * limit
                        total_batches += 1
                        continue

                        raw = await resp.json()

                    if not raw:
                        logger.debug(
                            "No klines for %s | batch %d — reached end of range",
                            symbol,
                            total_batches,
                        )
                        break

                    batch: List[OHLCV] = []
                    for k in raw:
                        batch.append(
                            OHLCV(
                                symbol=symbol,
                                timestamp=datetime.fromtimestamp(k[0] / 1000),
                                open=Decimal(k[1]),
                                high=Decimal(k[2]),
                                low=Decimal(k[3]),
                                close=Decimal(k[4]),
                                volume=Decimal(k[5]),
                                quote_asset_volume=Decimal(k[7]),
                                number_of_trades=int(k[8]),
                                taker_buy_base_volume=Decimal(k[9]),
                                taker_buy_quote_volume=Decimal(k[10]),
                            )
                        )

                    all_candles.extend(batch)

                    if len(raw) < limit:
                        # Received fewer candles than the limit — we've hit the
                        # end of available data for this range.
                        break
                    else:
                        current_start = batch[-1].timestamp + candle_duration

                    total_batches += 1
                    await asyncio.sleep(self.batch_delay)

                except asyncio.TimeoutError:
                    err = f"Batch {total_batches} timeout"
                    errors.append(err)
                    logger.warning(err)
                    current_start += candle_duration * limit
                except Exception as exc:
                    err = f"Batch {total_batches} error: {str(exc)[:120]}"
                    errors.append(err)
                    logger.warning(err)
                    current_start += candle_duration * limit

        return all_candles, errors

    def _detect_gaps(
        self,
        candles: List[OHLCV],
        timeframe_minutes: int,
    ) -> List[tuple[datetime, datetime]]:
        if len(candles) < 2:
            return []

        gaps = []
        expected_duration = timedelta(minutes=timeframe_minutes)

        for i in range(len(candles) - 1):
            current_end = candles[i].timestamp + expected_duration
            next_start = candles[i + 1].timestamp

            if next_start > current_end:
                gaps.append((current_end, next_start))

        return gaps

    def clear_cache(
        self,
        symbol: Optional[str] = None,
        market_type: Optional[MarketType] = None,
        timeframe: Optional[str] = None,
    ) -> int:
        cleared_count = 0

        if symbol and market_type and timeframe:
            cache_key = self._get_cache_key(symbol, market_type, timeframe)
            if cache_key in self._data_cache:
                del self._data_cache[cache_key]
                del self._cache_timestamps[cache_key]
                cleared_count = 1
        elif symbol and market_type:
            prefix = f"{symbol}_{market_type.value}_"
            keys_to_remove = [k for k in self._data_cache if k.startswith(prefix)]
            for k in keys_to_remove:
                del self._data_cache[k]
                del self._cache_timestamps[k]
            cleared_count = len(keys_to_remove)
        else:
            cleared_count = len(self._data_cache)
            self._data_cache.clear()
            self._cache_timestamps.clear()

        logger.info("Cache cleared | Entries removed: %d", cleared_count)
        return cleared_count

    def get_cache_info(self) -> dict:
        return {
            "cached_symbols": len(self._data_cache),
            "cache_size_kb": sum(len(v) for v in self._data_cache.values()) / 1000,
            "oldest_cache_age_hours": self._get_oldest_cache_age_hours(),
        }

    def _get_oldest_cache_age_hours(self) -> float:
        if not self._cache_timestamps:
            return 0
        oldest = min(self._cache_timestamps.values())
        age = datetime.utcnow() - oldest
        return age.total_seconds() / 3600
