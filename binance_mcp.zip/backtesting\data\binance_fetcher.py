"""
Binance Futures Data Fetcher
Fetch OHLCV candle data from Binance USDM Futures API
Supports 579+ symbols with fallback to Spot API
"""

from __future__ import annotations
import asyncio
import logging
from decimal import Decimal
from typing import Optional

import aiohttp
import pandas as pd
from pydantic import BaseModel

logger = logging.getLogger(__name__)

BINANCE_TESTNET_URL = "https://testnet.binancefuture.com"
BINANCE_MAINNET_URL = "https://fapi.binance.com"


class OHLCV(BaseModel):
    """OHLCV Candle Data"""
    timestamp: int
    open: Decimal
    high: Decimal
    low: Decimal
    close: Decimal
    volume: Decimal
    quote_asset_volume: Decimal
    trades: int


class BinanceFuturesDataFetcher:
    """Fetch OHLCV data from Binance USDM Futures"""
    
    def __init__(self, testnet: bool = True, timeout: int = 30):
        self.base_url = BINANCE_TESTNET_URL if testnet else BINANCE_MAINNET_URL
        self.timeout = aiohttp.ClientTimeout(total=timeout)
        self.session: Optional[aiohttp.ClientSession] = None
    
    async def __aenter__(self):
        self.session = aiohttp.ClientSession(timeout=self.timeout)
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.session:
            await self.session.close()
    
    async def get_exchange_info(self) -> dict:
        """Fetch all USDM Futures symbols (579+ total)"""
        try:
            url = f"{self.base_url}/fapi/v1/exchangeInfo"
            logger.info("Fetching exchange info from Binance...")
            
            async with self.session.get(url) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    symbols = [
                        s["symbol"] for s in data.get("symbols", [])
                        if s.get("status") == "TRADING"
                    ]
                    logger.info(f"✓ Fetched {len(symbols)} active symbols")
                    return {"symbols": symbols, "total": len(symbols)}
                else:
                    logger.error(f"✗ Exchange info error: {resp.status}")
                    return {"symbols": [], "total": 0}
        except Exception as e:
            logger.error(f"✗ Error fetching exchange info: {e}")
            return {"symbols": [], "total": 0}
    
    async def get_klines(
        self,
        symbol: str,
        interval: str = "1h",
        limit: int = 500,
        start_time: Optional[int] = None,
        end_time: Optional[int] = None
    ) -> list[OHLCV]:
        """
        Fetch OHLCV candles from Binance.
        
        Args:
            symbol: Trading symbol (BTCUSDT, ETHUSDT, etc.)
            interval: Candle interval (1m, 5m, 1h, 4h, 1d)
            limit: Number of candles (1-1500)
            start_time: Start timestamp in milliseconds
            end_time: End timestamp in milliseconds
        
        Returns:
            List of OHLCV objects
        """
        try:
            url = f"{self.base_url}/fapi/v1/klines"
            
            params = {
                "symbol": symbol.upper(),
                "interval": interval,
                "limit": min(limit, 1500)
            }
            
            if start_time:
                params["startTime"] = start_time
            if end_time:
                params["endTime"] = end_time
            
            logger.debug(f"Fetching {symbol} {interval} ({limit} candles)")
            
            async with self.session.get(url, params=params) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    candles = []
                    
                    for candle in data:
                        try:
                            ohlcv = OHLCV(
                                timestamp=int(candle[0]),
                                open=Decimal(str(candle[1])),
                                high=Decimal(str(candle[2])),
                                low=Decimal(str(candle[3])),
                                close=Decimal(str(candle[4])),
                                volume=Decimal(str(candle[7])),
                                quote_asset_volume=Decimal(str(candle[7])),
                                trades=int(candle[8])
                            )
                            candles.append(ohlcv)
                        except Exception as e:
                            logger.warning(f"✗ Error parsing candle: {e}")
                            continue
                    
                    if candles:
                        logger.info(f"✓ Got {len(candles)} {symbol} candles")
                        return candles
                    else:
                        logger.warning(f"⚠ No candles for {symbol}")
                        return await self._get_klines_fallback(symbol, interval, limit)
                else:
                    logger.warning(f"⚠ Status {resp.status}, trying fallback...")
                    return await self._get_klines_fallback(symbol, interval, limit)
        
        except asyncio.TimeoutError:
            logger.error(f"✗ Timeout for {symbol}")
            return []
        except Exception as e:
            logger.error(f"✗ Error: {e}")
            return []
    
    async def _get_klines_fallback(
        self,
        symbol: str,
        interval: str = "1h",
        limit: int = 500
    ) -> list[OHLCV]:
        """Fallback to Binance Spot API"""
        try:
            url = "https://api.binance.com/api/v3/klines"
            params = {
                "symbol": symbol.upper(),
                "interval": interval,
                "limit": min(limit, 1500)
            }
            
            logger.info(f"Using Spot API fallback for {symbol}...")
            
            async with self.session.get(url, params=params) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    candles = []
                    
                    for candle in data:
                        ohlcv = OHLCV(
                            timestamp=int(candle[0]),
                            open=Decimal(str(candle[1])),
                            high=Decimal(str(candle[2])),
                            low=Decimal(str(candle[3])),
                            close=Decimal(str(candle[4])),
                            volume=Decimal(str(candle[7])),
                            quote_asset_volume=Decimal(str(candle[7])),
                            trades=int(candle[8])
                        )
                        candles.append(ohlcv)
                    
                    logger.info(f"✓ Got {len(candles)} candles from Spot API")
                    return candles
                return []
        except Exception as e:
            logger.error(f"✗ Fallback failed: {e}")
            return []
    
    async def get_klines_batch(
        self,
        symbols: list[str],
        interval: str = "1h",
        limit: int = 500,
        concurrent: int = 10
    ) -> dict[str, list[OHLCV]]:
        """
        Fetch klines for multiple symbols concurrently.
        
        Args:
            symbols: List of symbols
            interval: Candle interval
            limit: Candles per symbol
            concurrent: Max concurrent requests (10 = safe limit)
        
        Returns:
            Dict mapping symbol -> list of OHLCV
        """
        results = {}
        semaphore = asyncio.Semaphore(concurrent)
        
        async def fetch_with_semaphore(symbol):
            async with semaphore:
                try:
                    candles = await self.get_klines(symbol, interval, limit)
                    return symbol, candles
                except Exception as e:
                    logger.error(f"Batch error for {symbol}: {e}")
                    return symbol, []
        
        logger.info(f"Batch fetching {len(symbols)} symbols (concurrent={concurrent})")
        
        tasks = [fetch_with_semaphore(sym) for sym in symbols]
        
        for coro in asyncio.as_completed(tasks):
            symbol, candles = await coro
            results[symbol] = candles
        
        successful = sum(1 for c in results.values() if c)
        logger.info(f"✓ Batch complete: {successful}/{len(symbols)} successful")
        
        return results
